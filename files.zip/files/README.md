# 🎓 O'quv Markaz Telegram Bot

## 📋 Imkoniyatlar

### 👨‍🎓 Foydalanuvchilar uchun:
- 📁 Kurslar ro'yxatini ko'rish
- 🎬 Video darslarni ko'rish
- 🔒 **Forward va saqlash taqiqi** (protect_content)
- ⬅️ ➡️ Darslar o'rtasida navigatsiya

### 👨‍💼 Adminlar uchun:
- ➕ Kategoriyalar qo'shish/o'chirish
- 🎬 Video darslar yuklash
- 📊 Statistika ko'rish
- 👥 Foydalanuvchilar ro'yxati
- 📢 Barcha foydalanuvchilarga xabar yuborish
- 🚫 Foydalanuvchilarni bloklash

---

## 🚀 O'rnatish va ishga tushirish

### 1. Kerakli kutubxonalarni o'rnatish:
```bash
pip install -r requirements.txt
```

### 2. Bot token olish:
1. Telegramda **@BotFather** ga yozing
2. `/newbot` buyrug'ini bering
3. Bot nomi va username kiriting
4. Olingan **token** ni `config.py` ga joylashtiring

### 3. Admin ID sini olish:
1. **@userinfobot** ga `/start` yuboring
2. Olingan `Id` raqamini `config.py` ga qo'shing

### 4. `config.py` ni sozlash:
```python
BOT_TOKEN = "1234567890:ABCdefGHIjklMNOpqrSTUvwxYZ"  # O'z tokeningiz
ADMIN_IDS = [123456789]  # O'z Telegram ID ingiz
BOT_NAME = "Mening O'quv Markazim"  # Bot nomi
```

### 5. Botni ishga tushirish:
```bash
python bot.py
```

---

## 📁 Fayl tuzilmasi

```
edu_bot/
├── bot.py          # Asosiy fayl
├── config.py       # Sozlamalar
├── database.py     # Ma'lumotlar bazasi
├── keyboards.py    # Tugmalar
├── requirements.txt
└── handlers/
    ├── __init__.py
    ├── user.py     # Foydalanuvchi handlerlari
    └── admin.py    # Admin handlerlari
```

---

## 🎮 Buyruqlar

| Buyruq | Tavsif |
|--------|--------|
| `/start` | Botni boshlash |
| `/admin` | Admin paneliga kirish |

---

## 🔒 Xavfsizlik

- `protect_content=True` — barcha video va hujjatlar **forward qilinmaydi** va **saqlanmaydi**
- Faqat `ADMIN_IDS` da ko'rsatilgan foydalanuvchilar admin bo'la oladi
- Bloklangan foydalanuvchilar botdan foydalana olmaydi

---

## ☁️ Server'ga joylashtirish (VPS)

```bash
# Screen yoki tmux bilan:
screen -S edu_bot
python bot.py

# Yoki systemd service sifatida (tavsiya etiladi)
```

---

## 📞 Yordam

Savollar bo'lsa, kod ichidagi kommentlarni o'qing yoki dasturchi bilan bog'laning.
